/**
 * Interface used by all the directory implementations, containing the methods
 * and parameters.
 * 
 * @author Joe Marke
 */
public interface Directory {

	// Adds the entries from the text file.
	public void addInitialEntries();
	
	// Allows a new entry to be added.
	public void addEntry(String surname, String initials, String number);

	// Allows an entry to be deleted, with input being name or number.
	public void deleteEntry(String str);

	// Allows a number to be changed.
	public void changeNumber(String surname, String newNumber);

	// Returns the extension number of an inputted name.
	public String lookup(String surname);

	// Prints a neat table.
	public void printTable();

}
