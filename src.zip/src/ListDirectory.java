import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Stores all entries from the text file in an linked list, including methods to
 * add or remove an entry, lookup an extension, change an extension and print a
 * table.
 * 
 * @author Joe Marke
 */
public class ListDirectory implements Directory {

	private List<String[]> directory; // Linked list of entries, where each
										// entry is an array.
	private int size; // Number of entries from the original text file.

	/**
	 * Adds the entries from the text file to the array.
	 */
	public void addInitialEntries() {
		try {
			BufferedReader firstIn = new BufferedReader(new FileReader("databig.txt"));// Attempts
																						// to
																						// read
																						// in
																						// the
																						// data
																						// from
																						// the
																						// file.

			while (firstIn.readLine() != null) {
				size++;// Counts the number of entries in the text file, and
						// sets the variable size to be that number.
			}
			firstIn.close(); // Close the buffered reader.
			directory = new LinkedList<String[]>(); // Directory is initialised,
													// as a linked list of
													// arrays.
			BufferedReader secondIn = new BufferedReader(new FileReader("databig.txt"));
			for (int i = 0; i < size; i++) {
				directory.add(secondIn.readLine().split("\t")); // Data from the
																// text file is
																// split by
																// tabs, then
																// inserted into
																// the
																// directory.
			}
			secondIn.close();

		} catch (FileNotFoundException e) { // Exceptions caught for if the file
											// isn't found or is the wrong type.
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println("Unable to read file");
		}
	}

	/**
	 * Adds an entry to the list.
	 * 
	 */
	public void addEntry(String surname, String initials, String number) {
		for (int i = 0; i < directory.size(); i++) { // Iterates through the
														// list to find the
														// position the new
														// entry should be
														// added,
														// alphabetically.
			if (directory.get(i)[0].compareTo(surname) > 0) {
				String[] entry = new String[3];
				entry[0] = surname;
				entry[1] = initials;
				entry[2] = number;
				directory.add(i, entry);
				break;
			}
		}
	}

	/**
	 * Returns the extension of an entry given their surname, using an iterating
	 * binary search.
	 */
	public String lookup(String surname) {
		int start = 0;
		int end = directory.size() - 1;

		while (start <= end) {
			int middle = (end + start) / 2;
			int compare = surname.compareTo(directory.get(middle)[0]); // Compares
																		// middle
																		// value
																		// to
																		// entered
																		// surname

			if (compare == 0) {
				return "The number of that person is: " + directory.get(middle)[2]; // If
																					// surname
																					// is
																					// found,
																					// return
				// the number of that entry.
			} else if (compare > 0) {
				start = middle + 1;
			} else if (compare < 0) {
				end = middle - 1;
			}
		}
		return "Name not found."; // If name isn't found.
	}

	/**
	 * Allows the user to input the surname of an entry, and a new extension
	 * number they wish to change to.
	 */
	public void changeNumber(String surname, String newNumber) {
		for (int i = 0; i < directory.size(); i++) {
			if (directory.get(i)[0].equals(surname)) {
				directory.get(i)[2] = newNumber;
			}
		}
	}

	/**
	 * Entries input via the surname or number can be deleted from the list.
	 */
	public void deleteEntry(String str) {
		for (int i = 0; i < directory.size(); i++) {
			if (directory.get(i)[2].equals(str)) {
				directory.remove(i);
			} else if (directory.get(i)[0].equals(str)) {
				directory.remove(i);
			}
		}
	}

	/**
	 * Prints a neat table of the directory.
	 */
	public void printTable() {
		for (int i = 0; i < directory.size(); i++) {
			System.out.println(Arrays.toString(directory.get(i)));
		}
	}

	public static void main(String[] args) {
		ListDirectory a = new ListDirectory();
		a.addInitialEntries();

		a.changeNumber("Zoane", "76543");
		a.printTable();
		
		 a.deleteEntry("Zeale");
		 a.printTable();

		 a.addEntry("Zazzy", "Z.G", "54080");
		 a.printTable();

		System.out.println(a.lookup("Zoane"));
	}

}
