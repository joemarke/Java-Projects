import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import javax.swing.*;

/**
 * Stores all entries from the text file in an array, including methods to add
 * or remove an entry, lookup an extension, change an extension and print a
 * table.
 * 
 * @author Joe Marke
 */
public class ArrayDirectory implements Directory {

	private String[][] directory; // Array to store all entries, which are an
									// array of size 3.
	private String[][] directoryAlt; // Secondary array for adding or removing
										// entries.
	private int size; // Number of entries from the original text file.

	/**
	 * Adds the entries from the text file to the array.
	 */
	public void addInitialEntries() {
		try {
			BufferedReader firstIn = new BufferedReader(new FileReader("databig.txt")); // Attempts
																						// to
																						// read
																						// in
																						// the
																						// data
																						// from
																						// the
																						// file.

			while (firstIn.readLine() != null) {
				size++; // Counts the number of entries in the text file, and
						// sets the variable size to be that number.
			}
			firstIn.close(); // Close the buffered reader.
			directory = new String[size][3]; // Directory is initialised, where
												// the second array of size 3
												// will contain the surname,
												// initials, and extension as
												// separate strings.
			BufferedReader secondIn = new BufferedReader(new FileReader("databig.txt"));
			for (int i = 0; i < size; i++) {
				directory[i] = secondIn.readLine().split("\t"); // Second
																// buffered
																// reader reads
																// in the text
																// file and adds
																// each entry to
																// the
																// directory,
																// with the tab
																// splitting the
																// 3 strings.
			}
			secondIn.close(); // Close the buffered reader.

		} catch (FileNotFoundException e) { // Exception for if the file is not
											// found.
			System.out.println("File not found");
		} catch (IOException e) { // Exception for if the file is the wrong
									// type.
			System.out.println("Unable to read file");
		}
	}

	/**
	 * Adds an entry to the array by using the second array, with size 1 bigger
	 * than the original array, adding the entry in the alphabetically correct
	 * location.
	 * 
	 */
	public void addEntry(String surname, String initials, String number) {
		for (int i = 0; i < directory.length; i++) { // Iterates through the
														// original array
			if (directory[i][0].compareTo(surname) < 0) { // If the entry is
															// alphabetically
															// after the other
															// entries, add it
				directoryAlt = new String[directory.length + 1][3]; // Initialises
																	// the
																	// second
																	// array
				for (int j = 0; j < i + 1; j++) { // Copies the entries from the
													// original array until the
													// point where the new entry
													// should be added,
													// alphabetically.
					directoryAlt[j] = directory[j];
				}
				directoryAlt[i + 1][0] = surname; // Adds the new entry to the
													// second array.
				directoryAlt[i + 1][1] = initials;
				directoryAlt[i + 1][2] = number;
				for (int k = (i + 2); k < directoryAlt.length; k++) {
					directoryAlt[k] = directory[k - 1]; // Adds the remaining
														// entries from the
														// original array to the
														// second array.
				}
			}
		}
	}

	/**
	 * Returns the extension of an entry given their surname, using an iterating
	 * binary search.
	 */
	public String lookup(String surname) {
		int start = 0;
		int end = directory.length - 1;

		while (start <= end) {
			int middle = (end + start) / 2; // Calculates the middle entry
											// index.
			int compare = surname.compareTo(directory[middle][0]); // Compares
																	// the
																	// surname
																	// to the
																	// entry's
																	// surname.

			if (compare == 0) {
				return "The number of that person is: " + directory[middle][2]; // If they are the same, return the
												// extension at that index.
			} else if (compare > 0) { // Looks for the entry in the right hand
										// side.
				start = middle + 1;
			} else if (compare < 0) { // Looks for the entry in the left hand
										// side.
				end = middle - 1;
			}
		}
		return "Name not found."; // If a name cannot be located, return this.
	}

	/**
	 * Allows the user to input the surname of an entry, and a new extension
	 * number they wish to change to.
	 */
	public void changeNumber(String surname, String newNumber) {
		for (int i = 0; i < directory.length; i++) { // Iterates through the
														// array.
			if (directory[i][0].equals(surname)) { // If the surname is found,
													// change the number.
				directory[i][2] = newNumber;
			}
		}
	}

	/**
	 * Entries input via the surname or number can be deleted from the array.
	 */
	public void deleteEntry(String str) {
		for (int i = 0; i < directory.length; i++) { // Iterates through the
														// array to find the
														// entry that is to be
														// deleted.
			if (directory[i][2].equals(str)) {
				directoryAlt = new String[directory.length - 1][3]; // Initialises
																	// the
																	// secondary
																	// array.
				for (int j = 0; j < i; j++) {
					directoryAlt[j] = directory[j]; // Copies the entries up to
													// where the entry that is
													// to be deleted is.
				}
				for (int k = i; k < directory.length - 1; k++) {
					directoryAlt[k] = directory[k + 1]; // Copies the remaining
														// entries into the
														// second array.
				}
			} else if (directory[i][0].equals(str)) { // Same method, but checks
														// for the surname
														// rather than the
														// extension number.
				directoryAlt = new String[directory.length - 1][3];
				for (int j = 0; j < i; j++) {
					directoryAlt[j] = directory[j];
				}
				for (int k = i; k < directory.length - 1; k++) {
					directoryAlt[k] = directory[k + 1];
				}
			}
		}
	}

	/**
	 * Prints a neat table of the directory.
	 */
	public void printTable() {
		for (int i = 0; i < directory.length; i++) {
			System.out.println(Arrays.toString(directory[i]));
		}
	}

	/**
	 * Prints a neat table of the altered directory, after an entry has been
	 * added or removed.
	 */
	public void rePrintTable() {
		for (int i = 0; i < directoryAlt.length; i++) {
			System.out.println(Arrays.toString(directoryAlt[i]));
		}

	}

	/**
	 * Creates a GUI for the user with all the functionality of the other
	 * methods.
	 */
	public void gui() {
		JFrame frame = new JFrame("Directory"); // New frame is initialised.
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // When closed,
																// the frame is
																// properly
																// exited.
		frame.setSize(800, 400);

		JPanel panel = new JPanel(); // Panel for the methods.
		panel.setLayout(new FlowLayout());
		JTextArea textArea = new JTextArea(); // Text area to print the
												// directory.
		JButton print = new JButton("Print Directory");
		JButton addEntry = new JButton("Add Entry");
		JButton deleteEntry = new JButton("Remove Entry");
		JButton changeNumber = new JButton("Change Number");
		JButton lookup = new JButton("Lookup Entry");

		panel.add(print); // Buttons are added to the panel after being
							// initialised.
		panel.add(addEntry);
		panel.add(deleteEntry);
		panel.add(changeNumber);
		panel.add(lookup);

		print.addActionListener(new ActionListener() { // For when the print
														// directory button is
														// pressed.
			public void actionPerformed(ActionEvent e) {
				textArea.setText(""); // Text area is cleared.
				for (int i = 0; i < directory.length; i++) {
					textArea.append(Arrays.toString(directory[i]) + "\n"); // Array
																			// is
																			// printed
																			// in
																			// the
																			// text
																			// area.
				}
			}
		});

		addEntry.addActionListener(new ActionListener() { // For when the add
															// entry button is
															// pressed.
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new JFrame("Add Entry"); // Creates a new frame.
				frame.setSize(400, 200);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLayout(new FlowLayout(FlowLayout.LEFT));

				// Allows the user to input the details of the entry they wish
				// to add.
				JLabel surnameLabel = new JLabel("Surname: ");
				JLabel initialsLabel = new JLabel("Initials: ");
				JLabel numberLabel = new JLabel("Number: ");
				JTextField surnameField = new JTextField(25);
				JTextField initialsField = new JTextField(25);
				JTextField numberField = new JTextField(25);
				JButton submit = new JButton("Submit"); // Submit button.

				// Buttons are added into their positions.
				frame.getContentPane().add(surnameLabel);
				frame.getContentPane().add(surnameField);
				frame.getContentPane().add(initialsLabel);
				frame.getContentPane().add(initialsField);
				frame.getContentPane().add(numberLabel);
				frame.getContentPane().add(numberField);
				frame.getContentPane().add(submit);

				submit.addActionListener(new ActionListener() { // For when
																// submit is
																// pressed.
					public void actionPerformed(ActionEvent e) {
						String surname = surnameField.getText(); // Data from
																	// the text
																	// fields
																	// are
																	// initialised
																	// as
																	// strings.
						String initials = initialsField.getText();
						String number = numberField.getText();
						frame.setVisible(false); // Pop up frame is closed.
						addEntry(surname, initials, number); // addEntry is
																// called.
						textArea.setText(""); // Text area is cleared.
						for (int i = 0; i < directoryAlt.length; i++) { // Prints
																		// the
																		// directory.
							textArea.append(Arrays.toString(directoryAlt[i]) + "\n");
						}
						textArea.append("The entry has been added, and the updated directory has been printed.");
					}
				});
				frame.setVisible(true); // Visibility of pop up is set to true.
			}

		});

		deleteEntry.addActionListener(new ActionListener() { // For when the
																// delete entry
																// button is
																// pressed.
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new JFrame("Delete Entry"); // Pop up frame is
															// initialised.
				frame.setSize(400, 200);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLayout(new FlowLayout(FlowLayout.LEFT));

				JLabel strLabel = new JLabel("Surname or Number: ");
				JTextField field = new JTextField(20);
				JButton submit = new JButton("Submit");

				frame.getContentPane().add(strLabel); // Components are put into
														// position.
				frame.getContentPane().add(field);
				frame.getContentPane().add(submit);

				submit.addActionListener(new ActionListener() { // For the
																// submit
																// button.
					public void actionPerformed(ActionEvent e) {
						String str = field.getText(); // Set a string to the
														// text field text.
						frame.setVisible(false); // Close pop up.
						deleteEntry(str); // Call delete entry method.
						textArea.setText(""); // Clear the text field then print
												// directory.
						for (int i = 0; i < directoryAlt.length; i++) {
							textArea.append(Arrays.toString(directoryAlt[i]) + "\n");
						}
						textArea.append("The entry has been deleted, and the updated directory has been printed.");
					}
				});
				frame.setVisible(true);
			}
		});

		changeNumber.addActionListener(new ActionListener() { // For when the
																// change number
																// button is
																// pressed.
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new JFrame("Change Number"); // New pop up frame
															// initialised.
				frame.setSize(400, 200);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLayout(new FlowLayout(FlowLayout.LEFT));

				JLabel surnameLabel = new JLabel("Surname: ");
				JLabel numberLabel = new JLabel("New Number: ");
				JTextField surnameField = new JTextField(25);
				JTextField numberField = new JTextField(24);
				JButton submit = new JButton("Submit");

				frame.getContentPane().add(surnameLabel);
				frame.getContentPane().add(surnameField);
				frame.getContentPane().add(numberLabel);
				frame.getContentPane().add(numberField);
				frame.getContentPane().add(submit);

				submit.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String surname = surnameField.getText();
						String number = numberField.getText();
						frame.setVisible(false); // Pop up frame is closed.
						changeNumber(surname, number); // changeNumber is
														// called.
						textArea.setText(""); // Updated directory is printed.
						for (int i = 0; i < directory.length; i++) {
							textArea.append(Arrays.toString(directory[i]) + "\n");
						}
						textArea.append("The entry has been changed, and the updated directory has been printed.");
					}
				});
				frame.setVisible(true);
			}

		});

		lookup.addActionListener(new ActionListener() { // For when the lookup
														// button is pressed.
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new JFrame("Lookup Entry");
				frame.setSize(400, 200);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLayout(new FlowLayout(FlowLayout.LEFT));

				JLabel surnameLabel = new JLabel("Surname: ");
				JTextField surnameField = new JTextField(25);
				JButton submit = new JButton("Submit");

				frame.getContentPane().add(surnameLabel);
				frame.getContentPane().add(surnameField);
				frame.getContentPane().add(submit);

				submit.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String surname = surnameField.getText();
						frame.setVisible(false);
						textArea.setText("Their number is: " + lookup(surname)); // Lookup
																					// method
																					// is
																					// called.
					}
				});
				frame.setVisible(true);
			}

		});

		frame.add(new JScrollPane(textArea), BorderLayout.CENTER); // Text area
																	// is
																	// scrollable
																	// and
																	// placed in
																	// position.
		frame.add(panel, BorderLayout.NORTH); // Panel of buttons is placed at
												// the top.
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		ArrayDirectory a = new ArrayDirectory();
		a.addInitialEntries();
		a.printTable();

		a.changeNumber("Zoane", "76543");
		a.printTable();

		a.deleteEntry("Zeale");
		a.rePrintTable();

		a.addEntry("Zazzy", "Z.G", "54080");
		a.rePrintTable();

		System.out.println(a.lookup("Zarfati"));

		// a.gui();
	}

}
