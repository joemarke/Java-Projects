import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Stores all entries from the text file in an array of 26 linked lists, with
 * entries separated alphabetically., including methods to add or remove an
 * entry, lookup an extension, change an extension and print a table.
 * 
 * @author Joe Marke
 */
public class HashDirectory {

	private List<String[]> directoryList; // List of entries, which are string
											// arrays.
	private List<String[]>[] directory; // Array of those lists.
	private int size; // Number of entries from the original text file.
	private int firstLetter = (int) 'A'; // ASCII code for the lowest letter the
											// string could start with; all
											// other letters in the alphabet
											// have higher values.

	/**
	 * Adds the entries from the text file to the array.
	 */
	public void addInitialEntries() {
		try {
			BufferedReader firstIn = new BufferedReader(new FileReader("databig.txt")); // Attempts
																						// to
																						// read
																						// in
																						// the
																						// data
																						// from
																						// the
																						// file.

			while (firstIn.readLine() != null) {
				size++; // Counts the number of entries in the text file, then
						// sets the variable to that number.
			}
			firstIn.close();
			directoryList = new LinkedList<String[]>(); // Initialise the list.
			BufferedReader secondIn = new BufferedReader(new FileReader("databig.txt"));
			for (int i = 0; i < size; i++) {
				directoryList.add(secondIn.readLine().split("\t")); // Adds the
																	// entries.
			}
			directory = new LinkedList[26]; // Initialise the array, size 26
											// because of 26 letters in the
											// alphabet.
			for (int i = 0; i < 26; i++) {
				directory[i] = new LinkedList<String[]>(); // Each of the
															// elements in the
															// array is a linked
															// list.
			}
			for (int i = 0; i < directory.length; i++) {
				for (int j = 0; j < size; j++)
					if (directoryList.get(j)[0].charAt(0) == (firstLetter + i)) {
						directory[i].add(directoryList.get(j)); // Adds all
																// elements
																// beginning
																// with the same
																// letter to the
																// same array
																// element.
					}
			}
			secondIn.close();

		} catch (FileNotFoundException e) { // Exceptions caught.
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println("Unable to read file");
		}
	}

	/**
	 * Adds an entry to the correct list within the array.
	 * 
	 */
	public void addEntry(String surname, String initials, String number) {
		char letter = surname.charAt(0); // The first letter of the surname is
											// found, so it can be inserted into
											// the correct list.
		for (int i = firstLetter; i < directory.length + firstLetter; i++) {
			if (letter == i) { // Checks what list the name should be inserted
								// to.
				for (int j = 0; j < directory[i - firstLetter].size(); j++) {
					if (directory[i - firstLetter].get(j)[0].compareTo(surname) > 0) {
						String[] entry = new String[3]; // Creates new entry to
														// be added.
						entry[0] = surname;
						entry[1] = initials;
						entry[2] = number;
						directory[i - firstLetter].add(entry);
						break;
					}
				}
			}
		}

	}

	/**
	 * Returns the extension of an entry given their surname, using hashing. The
	 * correct list in located first via the first letter of the surname, then
	 * iterated through.
	 */
	public String lookup(String surname) {
		char letter = surname.charAt(0);
		for (int i = 0; i < directory[letter - firstLetter].size(); i++) {
			if (directory[letter - firstLetter].get(i)[0].equals(surname)) {
				return "The number of that person is: " + directory[letter - firstLetter].get(i)[2];
			}
		}
		return "Name not found.";
	}

	/**
	 * Allows the user to input the surname of an entry, and a new extension
	 * number they wish to change to.
	 */
	public void changeNumber(String surname, String newNumber) {
		char letter = surname.charAt(0);
		for (int i = firstLetter; i < directory.length + firstLetter; i++) {
			if (letter == i) {
				for (int j = 0; j < directory[i - firstLetter].size(); j++) {
					if (directory[i - firstLetter].get(j)[0].equals(surname)) {
						directory[i - firstLetter].get(j)[2] = newNumber;
					}
				}
			}
		}
	}

	/**
	 * Entries input via the surname or number can be deleted from the list.
	 */
	public void deleteEntry(String str) {
		for (int i = firstLetter; i < directory.length + firstLetter; i++) {
			for (int j = 0; j < directory[i - firstLetter].size(); j++) {
				if (directory[i - firstLetter].get(j)[2].equals(str)) {
					directory[i - firstLetter].remove(j);
				} else if (directory[i - firstLetter].get(j)[0].equals(str)) {
					directory[i - firstLetter].remove(j);
				}
			}
		}
	}

	/**
	 * Prints a neat table of the directory.
	 */
	public void printTable() {
		for (int i = 0; i < directory.length; i++) {
			for (int j = 0; j < directory[i].size(); j++) {
				System.out.println(Arrays.toString(directory[i].get(j)));
			}
		}
	}

	public static void main(String[] args) {
		HashDirectory a = new HashDirectory();
		a.addInitialEntries();

		a.changeNumber("Zoane", "76543");
		a.printTable();

		a.deleteEntry("Zeale");
		a.printTable();

		a.addEntry("Zazzy", "Z.G", "54080");
		a.printTable();

		System.out.println(a.lookup("Zarfati"));

	}

}
